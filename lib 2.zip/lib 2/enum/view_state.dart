enum ViewState { idle, busy }
