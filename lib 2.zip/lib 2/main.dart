// lib/main.dart
import 'package:flutter/material.dart';

void main() => runApp(const SmartHomeDemoApp());

class SmartHomeDemoApp extends StatelessWidget {
  const SmartHomeDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    const primaryAccent = Color(0xFFF4AE47); // фирменное «золото»
    const bg = Color(0xFFF7F7F9);
    const card = Colors.white;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Home (Static Demo)',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primaryAccent,
          brightness: Brightness.light,
          primary: primaryAccent,
          surface: card,
          background: bg,
        ),
        scaffoldBackgroundColor: bg,
        textTheme: const TextTheme(
          displaySmall: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 26,
            letterSpacing: -.2,
            color: Color(0xFF2B2B2B),
          ),
          titleLarge: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: Color(0xFF2B2B2B),
          ),
          titleMedium: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            color: Color(0xFF2B2B2B),
          ),
          bodyLarge: TextStyle(
            fontSize: 14,
            color: Color(0xFF616161),
          ),
          bodyMedium: TextStyle(
            fontSize: 13,
            color: Color(0xFF7B7B7B),
          ),
          labelLarge: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        cardTheme: CardTheme(
          color: card,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      home: const _BottomNav(),
    );
  }
}

/* ---------------------------------- NAV ---------------------------------- */

class _BottomNav extends StatefulWidget {
  const _BottomNav();

  @override
  State<_BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<_BottomNav> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeScreen(),
      const RoomsScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Rooms'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

/* --------------------------------- HOME ---------------------------------- */

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<DeviceTileData> devices;

  @override
  void initState() {
    super.initState();
    devices = [
      DeviceTileData(
        name: 'Living Lamp',
        icon: Icons.lightbulb_outline,
        isOn: true,
        room: 'Living',
      ),
      DeviceTileData(
        name: 'Floor Lamp',
        icon: Icons.light_rounded,
        isOn: false,
        room: 'Living',
      ),
      DeviceTileData(
        name: 'AC Unit',
        icon: Icons.ac_unit_rounded,
        isOn: true,
        room: 'Bedroom',
      ),
      DeviceTileData(
        name: 'Smart TV',
        icon: Icons.tv_rounded,
        isOn: false,
        room: 'Bedroom',
      ),
      DeviceTileData(
        name: 'Air Purifier',
        icon: Icons.air_rounded,
        isOn: true,
        room: 'Studio',
      ),
      DeviceTileData(
        name: 'Ceiling Light',
        icon: Icons.light_mode_outlined,
        isOn: false,
        room: 'Kitchen',
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final color = Theme.of(context).colorScheme;

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 210,
          backgroundColor: color.background,
          flexibleSpace: FlexibleSpaceBar(
            background: _HeaderGradient(),
            titlePadding: const EdgeInsetsDirectional.only(start: 16, bottom: 14),
            title: Row(
              children: [
                const CircleAvatar(
                  radius: 16,
                  backgroundImage: AssetImage('assets/noimage.png'),
                  backgroundColor: Colors.white12,
                ),
                const SizedBox(width: 10),
                Text('Good morning, Alex', style: tt.titleLarge!.copyWith(color: Colors.white)),
              ],
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search_rounded, color: Colors.white),
              onPressed: () {},
            ),
            const SizedBox(width: 8),
          ],
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Overview', style: tt.displaySmall),
                const SizedBox(height: 12),
                const _SavingsCard(),
                const SizedBox(height: 12),
                const _WeatherCard(),
                const SizedBox(height: 16),
                _QuickActions(onToggleAll: _toggleAllOn, onPowerOffAll: _powerOffAll),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Favourites', style: tt.titleLarge),
                    TextButton(onPressed: () {}, child: const Text('See all')),
                  ],
                ),
                const SizedBox(height: 8),
                _FavouritesStrip(devices: devices.take(4).toList()),
                const SizedBox(height: 20),
                Text('Devices', style: tt.titleLarge),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),

        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          sliver: SliverGrid.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .98),
            itemCount: devices.length,
            itemBuilder: (_, i) => _DeviceCard(
              data: devices[i],
              onChanged: (v) => setState(() => devices[i] = devices[i].copyWith(isOn: v)),
            ),
          ),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 28)),
      ],
    );
  }

  void _toggleAllOn() => setState(() {
        for (var i = 0; i < devices.length; i++) {
          devices[i] = devices[i].copyWith(isOn: true);
        }
      });

  void _powerOffAll() => setState(() {
        for (var i = 0; i < devices.length; i++) {
          devices[i] = devices[i].copyWith(isOn: false);
        }
      });
}

class _HeaderGradient extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(-.6, -1),
          end: Alignment(.8, 1),
          colors: [Color(0xFF2E335A), Color(0xFF1C1B33), Color(0xFF0D0C1B)],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned(
            right: -40,
            top: -20,
            child: Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(.06),
              ),
            ),
          ),
          Positioned(
            left: -30,
            bottom: -30,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(.05),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/* ----------------------------- OVERVIEW CARDS ----------------------------- */

class _SavingsCard extends StatelessWidget {
  const _SavingsCard();

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final cs = Theme.of(context).colorScheme;

    return Card(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [cs.primary.withOpacity(.16), Colors.white],
          ),
        ),
        child: Row(
          children: [
            Container(
              decoration: BoxDecoration(
                color: cs.primary.withOpacity(.18),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(12),
              child: Icon(Icons.savings_rounded, color: cs.primary, size: 28),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total savings', style: tt.titleMedium),
                  const SizedBox(height: 4),
                  Text('129 kWh', style: tt.displaySmall),
                  const SizedBox(height: 2),
                  Text('This month', style: tt.bodyMedium),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.trending_down_rounded, size: 16, color: Colors.green),
                  SizedBox(width: 6),
                  Text('-12%', style: TextStyle(color: Colors.green, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WeatherCard extends StatelessWidget {
  const _WeatherCard();

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;

    return Card(
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const Icon(Icons.wb_sunny_rounded, size: 42, color: Color(0xFFFFC107)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Weather', style: tt.titleMedium),
                  const SizedBox(height: 2),
                  Text('Sunny · 26° / 14°', style: tt.bodyLarge),
                ],
              ),
            ),
            const _Pill(text: 'Almaty'),
          ],
        ),
      ),
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({required this.onToggleAll, required this.onPowerOffAll});
  final VoidCallback onToggleAll;
  final VoidCallback onPowerOffAll;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Row(
      children: [
        Expanded(
          child: _ActionButton(
            icon: Icons.power,
            label: 'Switch all',
            onTap: onToggleAll,
            bg: cs.primary,
            fg: Colors.black,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.power_off,
            label: 'Power off',
            onTap: onPowerOffAll,
            bg: Colors.black,
            fg: Colors.white,
          ),
        ),
        const SizedBox(width: 12),
        SizedBox(
          width: 54,
          child: _IconSquare(
            icon: Icons.lock_outline_rounded,
            tooltip: 'Security',
            onTap: () {},
          ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.bg,
    required this.fg,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color bg;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: fg),
              const SizedBox(width: 8),
              Text(label, style: Theme.of(context).textTheme.labelLarge!.copyWith(color: fg)),
            ],
          ),
        ),
      ),
    );
  }
}

class _IconSquare extends StatelessWidget {
  const _IconSquare({required this.icon, required this.tooltip, required this.onTap});
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: cs.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            height: 48,
            child: Center(child: Icon(icon, color: cs.onSurface)),
          ),
        ),
      ),
    );
  }
}

/* ------------------------------- FAVOURITES ------------------------------- */

class _FavouritesStrip extends StatelessWidget {
  const _FavouritesStrip({required this.devices});
  final List<DeviceTileData> devices;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return SizedBox(
      height: 86,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: devices.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final d = devices[i];
          return Container(
            width: 140,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: cs.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.black12.withOpacity(.06)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: (d.isOn ? cs.primary : cs.surfaceTint).withOpacity(.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(d.icon, size: 22, color: d.isOn ? cs.primary : Colors.grey),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(d.name, maxLines: 2, overflow: TextOverflow.ellipsis),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/* -------------------------------- DEVICES -------------------------------- */

class DeviceTileData {
  final String name;
  final IconData icon;
  final bool isOn;
  final String room;

  DeviceTileData({
    required this.name,
    required this.icon,
    required this.isOn,
    required this.room,
  });

  DeviceTileData copyWith({String? name, IconData? icon, bool? isOn, String? room}) {
    return DeviceTileData(
      name: name ?? this.name,
      icon: icon ?? this.icon,
      isOn: isOn ?? this.isOn,
      room: room ?? this.room,
    );
  }
}

class _DeviceCard extends StatelessWidget {
  const _DeviceCard({required this.data, required this.onChanged});
  final DeviceTileData data;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return Card(
      child: Container(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _DeviceBadge(icon: data.icon, active: data.isOn),
            const SizedBox(height: 12),
            Text(data.name, style: tt.titleMedium, maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(data.room, style: tt.bodyMedium),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: _Pill(
                    text: data.isOn ? 'On' : 'Off',
                    fg: data.isOn ? Colors.green.shade700 : Colors.grey.shade700,
                    bg: data.isOn ? Colors.green.shade50 : Colors.grey.shade200,
                  ),
                ),
                const SizedBox(width: 8),
                Switch.adaptive(
                  value: data.isOn,
                  onChanged: onChanged,
                  activeColor: Colors.black,
                  activeTrackColor: cs.primary,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DeviceBadge extends StatelessWidget {
  const _DeviceBadge({required this.icon, required this.active});
  final IconData icon;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: (active ? cs.primary : cs.surfaceTint).withOpacity(.14),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, color: active ? cs.primary : Colors.grey[600]),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, this.bg, this.fg});

  final String text;
  final Color? bg;
  final Color? fg;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg ?? cs.primary.withOpacity(.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelLarge!.copyWith(color: fg ?? Colors.black),
      ),
    );
  }
}

/* ------------------------------ OTHER TABS ------------------------------- */

class RoomsScreen extends StatelessWidget {
  const RoomsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final rooms = const [
      ('Living Room', Icons.weekend_outlined, 4),
      ('Bedroom', Icons.king_bed_outlined, 3),
      ('Kitchen', Icons.kitchen_outlined, 2),
      ('Studio', Icons.desktop_windows_outlined, 2),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Rooms', style: tt.displaySmall),
          const SizedBox(height: 12),
          ...rooms.map((r) => Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(.18),
                    child: Icon(r.$2, color: Theme.of(context).colorScheme.primary),
                  ),
                  title: Text(r.$1, style: tt.titleMedium),
                  subtitle: Text('${r.$3} devices connected'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () {},
                ),
              )),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Profile', style: tt.displaySmall),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text('Alex Johnson', style: tt.titleMedium),
              subtitle: const Text('alex@example.com'),
              trailing: const Icon(Icons.edit_outlined),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: const [
                _ProfileTile(icon: Icons.lock_outline_rounded, title: 'Security'),
                Divider(height: 1),
                _ProfileTile(icon: Icons.notifications_outlined, title: 'Notifications'),
                Divider(height: 1),
                _ProfileTile(icon: Icons.language_rounded, title: 'Language'),
                Divider(height: 1),
                _ProfileTile(icon: Icons.help_outline_rounded, title: 'Help & Support'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.tonal(
            onPressed: () {},
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return ListTile(
      leading: Icon(icon),
      title: Text(title, style: tt.titleMedium),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: () {},
    );
  }
}
