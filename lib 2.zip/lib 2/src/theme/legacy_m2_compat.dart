// lib/src/theme/legacy_m2_compat.dart
import 'package:flutter/material.dart';

/// 1) Возвращаем старые геттеры у TextTheme через extension.
///    Теперь в любом месте можно писать:
///    Theme.of(context).textTheme.headline2 / bodyText1 / caption и т.д.
extension LegacyM2TextTheme on TextTheme {
  // M2 -> M3 соответствия
  TextStyle? get headline1 => displayLarge;
  TextStyle? get headline2 => displayMedium;
  TextStyle? get headline3 => displaySmall;
  // Подбираем наиболее близкие по смыслу варианты
  TextStyle? get headline4 => headlineLarge;
  TextStyle? get headline5 => headlineSmall;
  TextStyle? get headline6 => titleLarge;

  TextStyle? get bodyText1 => bodyLarge;
  TextStyle? get bodyText2 => bodyMedium;
  TextStyle? get caption => bodySmall;
  TextStyle? get subtitle1 => titleMedium;
  TextStyle? get subtitle2 => titleSmall;
  TextStyle? get button => labelLarge;
  TextStyle? get overline => labelSmall;
}

/// 2) Удобный доступ к стилям через context:
///    context.tt.headline2, context.tt.bodyText1 и т.д.
///    И сразу новые M3-имена: context.ttM3.displayLarge и т.п.
extension BuildContextText on BuildContext {
  TextTheme get tt => Theme.of(this).textTheme; // M2 алиасы тоже здесь
  TextTheme get ttM3 => Theme.of(this).textTheme;

  // Часто встречающееся в коде «displayLarge» без Theme.of(...):
  // можно заменить на context.displayLarge.
  TextStyle? get displayLarge => tt.displayLarge;
  TextStyle? get displayMedium => tt.displayMedium;
  TextStyle? get displaySmall => tt.displaySmall;
  TextStyle? get headlineLarge => tt.headlineLarge;
  TextStyle? get headlineSmall => tt.headlineSmall;
  TextStyle? get titleLarge => tt.titleLarge;
  TextStyle? get bodyLarge => tt.bodyLarge;
  TextStyle? get bodyMedium => tt.bodyMedium;
  TextStyle? get bodySmall => tt.bodySmall;
}
