// lib/features/security_control/hub_detail_screen.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ISS/appColor.dart';
import 'package:ISS/models/hub_models.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

class HubDetailsScreen extends StatelessWidget {
  final HubObject hub;

  const HubDetailsScreen({Key? key, required this.hub}) : super(key: key);

  IconData _getIconForParameter(String key) {
    switch (key.toLowerCase()) {
      case 'temperature':
      case 'temp':
        return Icons.thermostat_outlined;
      case 'humidity':
        return Icons.opacity;
      case 'state':
      case 'status':
        return Icons.info_outline;
      case 'battery':
      case 'battery_level': // Добавил, если приходит как 'battery_level'
        return Icons.battery_full;
      case 'motion':
        return Icons.directions_run;
      case 'light':
        return Icons.lightbulb_outline;
      case 'pressure':
        return Icons.speed;
      default:
        return Icons.settings;
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd.MM.yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: Text(hub.facilityName),
        backgroundColor: AppColors.secodnBg,
      ),
      backgroundColor: AppColors.background,
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          // Информация по хабу
          Card(
            color: AppColors.secodnBg,
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hub.facilityName,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    hub.address,
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Статус: ${hub.statusNameRus} (${hub.connected ? "Онлайн" : "Оффлайн"})',
                    style: TextStyle(color: hub.connected ? Colors.green : Colors.redAccent),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'ID хаба: ${hub.hubNumber}',
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),

          // Список устройств
          if (hub.devices.isEmpty)
            const Center(
              child: Text('Нет устройств', style: TextStyle(color: Colors.white54)),
            )
          else
            ...hub.devices.map(
              (device) => Card(
                color: AppColors.secodnBg,
                margin: const EdgeInsets.symmetric(vertical: 6),
                child: GestureDetector(
                  onDoubleTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => DeviceControlScreen(device: device, hubId: hub.id),
                      ),
                    );
                  },
                  child: ExpansionTile(
                    iconColor: AppColors.primary,
                    collapsedIconColor: Colors.white,
                    backgroundColor: AppColors.secodnBg,
                    collapsedBackgroundColor: AppColors.secodnBg,
                    title: Text(
                      device.name,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(
                      'Последнее обновление: ${dateFormat.format(device.lastUpdate)}',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                    childrenPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    children: device.parameters.entries.map((entry) {
                      final key = entry.key;
                      final value = entry.value;

                      return ListTile(
                        leading: Icon(_getIconForParameter(key), color: AppColors.primary),
                        title: Text(
                          key,
                          style: const TextStyle(color: Colors.white70),
                        ),
                        trailing: Text(
                          value.toString(),
                          style: const TextStyle(color: Colors.white),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// Пример простого экрана управления устройством (импортируй отдельно или допиши в этот файл)
class DeviceControlScreen extends StatefulWidget {
  final Device device;
  final String hubId;

  const DeviceControlScreen({Key? key, required this.device, required this.hubId}) : super(key: key);

  @override
  _DeviceControlScreenState createState() => _DeviceControlScreenState();
}

class _DeviceControlScreenState extends State<DeviceControlScreen> {
  late WebSocketChannel channel;
  bool isConnected = false;
  bool isOn = false;
  int brightness = 0;

  @override
  void initState() {
    super.initState();
    _initWebSocket();
  }

  Future<void> _initWebSocket() async {
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken'); // Используем String? для возможности null

    // *** ИСПРАВЛЕНИЕ 1: Удаление префикса "Bearer " из токена ***
    if (token != null && token.startsWith('Bearer ')) {
      token = token.substring(7);
    }
    // Если токен все еще null или пустой после обработки, возможно, стоит показать ошибку
    if (token == null || token.isEmpty) {
      print('Ошибка: Токен доступа не найден или пуст.');
      setState(() => isConnected = false);
      return; // Прекращаем попытку соединения, если токена нет
    }


    final url = 'wss://cms.iss-control.kz:8443/ws?token=$token';
    try {
      channel = WebSocketChannel.connect(Uri.parse(url));

      channel.stream.listen(
        (message) {
          final data = jsonDecode(message);
          if (data['type'] == 'DEVICE_STATE_UPDATE' && data['details'] != null) {
            final details = data['details'];
            if (details['deviceId'] == widget.device.id) {
              setState(() {
                isOn = details['payload']['state']?.toString().toUpperCase() == 'ON';
                // *** ИСПРАВЛЕНИЕ 2: Преобразование brightness к int ***
                final dynamic rawBrightness = details['payload']['brightness'];
                if (rawBrightness is int) {
                  brightness = rawBrightness;
                } else if (rawBrightness is String) {
                  brightness = int.tryParse(rawBrightness) ?? brightness;
                } else {
                  brightness = brightness; // Сохраняем текущее значение, если тип неизвестен
                }
              });
            }
          }
        },
        onDone: () {
          setState(() => isConnected = false);
          print('WebSocket соединение закрыто.');
        },
        onError: (error) {
          setState(() => isConnected = false);
          print('WebSocket ошибка: $error');
          // Добавьте более детальную обработку ошибок, если нужно
          // Например, SnackBar с сообщением пользователю
        },
      );

      setState(() {
        isConnected = true;
        // Эти начальные значения берутся из объекта устройства,
        // они будут обновлены при получении данных через WebSocket
        isOn = widget.device.parameters['state']?.toString().toUpperCase() == 'ON';
        brightness = widget.device.parameters['brightness'] is int
            ? widget.device.parameters['brightness']
            : (widget.device.parameters['brightness'] is String
                ? int.tryParse(widget.device.parameters['brightness'].toString()) ?? 0
                : 0);
      });
    } catch (e) {
      print('Ошибка при подключении к WebSocket: $e');
      setState(() => isConnected = false);
    }
  }

  void _sendCommand(Map<String, dynamic> payload) {
    if (channel.sink != null) { // Убедитесь, что канал инициализирован
      final command = {
        "type": "DEVICE_COMMAND",
        "hubId": widget.hubId,
        "details": {
          "deviceId": widget.device.id,
          "payload": payload,
        }
      };
      channel.sink.add(jsonEncode(command));
    } else {
      print('WebSocket канал не инициализирован. Не удалось отправить команду.');
    }
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.device.name),
        backgroundColor: AppColors.secodnBg,
      ),
      backgroundColor: AppColors.background,
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Вкл/Выкл', style: TextStyle(color: Colors.white)),
              value: isOn,
              onChanged: (value) {
                setState(() => isOn = value);
                _sendCommand({"state": value ? "ON" : "OFF"});
              },
              activeColor: AppColors.primary,
            ),
            const SizedBox(height: 20),
            Text('Яркость: $brightness', style: const TextStyle(color: Colors.white)),
            Slider(
              value: brightness.toDouble(),
              min: 0,
              max: 255, // Максимальное значение для яркости
              divisions: 255,
              activeColor: AppColors.primary,
              inactiveColor: Colors.white24,
              onChanged: (value) {
                setState(() => brightness = value.toInt());
                _sendCommand({"brightness": brightness});
              },
            ),
            const SizedBox(height: 20),
            isConnected
                ? const Text('Соединение активно', style: TextStyle(color: Colors.green))
                : const Text('Соединение отсутствует', style: TextStyle(color: Colors.redAccent)),
          ],
        ),
      ),
    );
  }
}