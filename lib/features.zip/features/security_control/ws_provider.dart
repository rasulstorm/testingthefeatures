import 'dart:async';
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:web_socket_channel/io.dart';

final webSocketProvider = StateNotifierProvider<WebSocketNotifier, Map<String, dynamic>>(
  (ref) => WebSocketNotifier(),
);

class WebSocketNotifier extends StateNotifier<Map<String, dynamic>> {
  WebSocketNotifier() : super({});

  late IOWebSocketChannel _channel;
  bool _connected = false;
  bool get connected => _connected;

  Timer? _reconnectTimer;

  Future<void> connect(String hubId, String deviceId, {required String token}) async {
    if (_connected) {
      print('[WS] Already connected. Skipping connect call.');
      return;
    }

    final url = 'wss://cms.iss-control.kz:8443/ws?token=$token';
    print('[WS] Trying to connect to $url with hubId=$hubId deviceId=$deviceId');

    try {
      _channel = IOWebSocketChannel.connect(Uri.parse(url));
      _connected = true;
      print('[WS] WebSocket connection established.');

      _channel.stream.listen(
        (message) {
          print('[WS] Message received: $message');

          try {
            final data = jsonDecode(message);
            if (data['type'] == 'DEVICE_STATE_UPDATE') {
              final incomingDeviceId = data['deviceId'] ?? 'unknown';
              print('[WS] DEVICE_STATE_UPDATE for deviceId=$incomingDeviceId');

              if (incomingDeviceId == deviceId) {
                final payload = data['payload'] ?? {};
                print('[WS] Updating state with payload: $payload');
                state = Map<String, dynamic>.from(payload);
              } else {
                print('[WS] Ignored update for deviceId=$incomingDeviceId (looking for $deviceId)');
              }
            } else {
              print('[WS] Ignored message with type: ${data['type']}');
            }
          } catch (e) {
            print('[WS] Error decoding message: $e');
          }
        },
        onDone: () {
          print('[WS] Connection closed.');
          _connected = false;
          _scheduleReconnect(hubId, deviceId, token);
        },
        onError: (error) {
          print('[WS] Connection error: $error');
          _connected = false;
          _scheduleReconnect(hubId, deviceId, token);
        },
        cancelOnError: true,
      );
    } catch (e) {
      print('[WS] Failed to connect: $e');
      _connected = false;
      _scheduleReconnect(hubId, deviceId, token);
    }
  }

  void _scheduleReconnect(String hubId, String deviceId, String token) {
    print('[WS] Scheduling reconnect in 5 seconds...');
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      print('[WS] Attempting to reconnect...');
      connect(hubId, deviceId, token: token);
    });
  }

  void sendCommand(String hubId, String deviceId, Map<String, dynamic> payload) {
    if (!_connected) {
      print('[WS] Cannot send command: Not connected');
      return;
    }
    final command = {
      "type": "DEVICE_COMMAND",
      "hubId": hubId,
      "details": {
        "deviceId": deviceId,
        "payload": payload,
      },
    };
    final jsonCmd = jsonEncode(command);
    print('[WS] Sending command: $jsonCmd');
    _channel.sink.add(jsonCmd);
  }

  @override
  void dispose() {
    print('[WS] Disposing WebSocketNotifier...');
    _reconnectTimer?.cancel();
    _channel.sink.close();
    super.dispose();
  }
}
