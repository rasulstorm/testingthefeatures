// device_control_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ws_provider.dart';

class DeviceControlScreen extends ConsumerStatefulWidget {
  final String hubId;
  final String deviceName;  // Изменено с deviceId на deviceName

  const DeviceControlScreen({
    super.key,
    required this.hubId,
    required this.deviceName,
  });

  @override
  ConsumerState<DeviceControlScreen> createState() => _DeviceControlScreenState();
}

class _DeviceControlScreenState extends ConsumerState<DeviceControlScreen> {
  String? _token;

  @override
  void initState() {
    super.initState();
    print('[DeviceControl] initState: hubId=${widget.hubId}, deviceName=${widget.deviceName}');
    _loadTokenAndConnect();
  }

  Future<void> _loadTokenAndConnect() async {
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken');

    if (token == null) {
      print('[DeviceControl] Token not found!');
      return;
    }

    if (token.startsWith('Bearer ')) {
      token = token.substring(7);
      print('[DeviceControl] Token stripped "Bearer ": $token');
    }

    setState(() {
      _token = token;
    });

    print('[DeviceControl] Connecting WebSocket with token...');
    ref.read(webSocketProvider.notifier).connect(widget.hubId, widget.deviceName, token: token);
  }

  @override
  Widget build(BuildContext context) {
    final deviceState = ref.watch(webSocketProvider);
    final isConnected = ref.read(webSocketProvider.notifier).connected;

    print('[DeviceControl] Current deviceState: $deviceState');
    print('[DeviceControl] WebSocket connected: $isConnected');

    bool isOn = false;
    if (deviceState.containsKey('state')) {
      final stateValue = deviceState['state'];
      if (stateValue is bool) {
        isOn = stateValue;
      } else if (stateValue is String) {
        isOn = stateValue.toLowerCase() == 'on' || stateValue.toLowerCase() == 'true';
      }
    }
    print('[DeviceControl] isOn = $isOn');

    double brightness = 0.0;
    if (deviceState.containsKey('brightness')) {
      final brightnessRaw = deviceState['brightness'];
      if (brightnessRaw is int) {
        brightness = brightnessRaw.toDouble();
      } else if (brightnessRaw is String) {
        brightness = double.tryParse(brightnessRaw) ?? 0.0;
      }
      brightness = brightness.clamp(0.0, 100.0);
    }
    print('[DeviceControl] brightness = $brightness');

    return Scaffold(
      appBar: AppBar(title: const Text('Управление устройством')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Включено'),
              value: isOn,
              onChanged: (val) {
                print('[DeviceControl] Switch changed to: $val');
                ref.read(webSocketProvider.notifier).sendCommand(widget.hubId, widget.deviceName, {'state': val ? 'ON' : 'OFF'});
              },
            ),
            const SizedBox(height: 20),
            if (deviceState.containsKey('brightness'))
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Яркость', style: TextStyle(fontWeight: FontWeight.bold)),
                  Slider(
                    value: brightness,
                    min: 0,
                    max: 100,
                    divisions: 100,
                    label: '${brightness.toInt()}%',
                    onChanged: (val) {
                      print('[DeviceControl] Brightness slider changed to: $val');
                      ref.read(webSocketProvider.notifier).sendCommand(widget.hubId, widget.deviceName, {'brightness': val.toInt()});
                    },
                  ),
                ],
              ),
            if (!isConnected)
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text('Ожидание подключения...', style: TextStyle(color: Colors.red[300])),
              ),
          ],
        ),
      ),
    );
  }
}
